#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
HERE="$(cd "$(dirname "$0")" && pwd)"
if [[ ! -f "$ROOT/index.html" || ! -f "$ROOT/app.js" ]]; then
  echo "ERROR: $ROOT does not look like the FKBC flat-PWA repo root."
  echo "Run: ./apply_update.sh /workspaces/YOUR-REPO"
  exit 1
fi
STAMP="$(date +%Y%m%d-%H%M%S)"
mkdir -p "$ROOT/.fkbc-backup-$STAMP"
for f in app.js styles.css index.html sw.js sfx_punch.wav sfx_kick.wav sfx_heavy.wav sfx_block.wav sfx_fireball.wav sfx_tornado.wav sfx_knockdown.wav sfx_win.wav sfx_round.wav sfx_select.wav; do
  [[ -f "$ROOT/$f" ]] && cp "$ROOT/$f" "$ROOT/.fkbc-backup-$STAMP/$f"
  cp "$HERE/replacements/$f" "$ROOT/$f"
done
node --check "$ROOT/app.js"
python3 -m json.tool "$ROOT/assets.json" >/dev/null
python3 -m json.tool "$ROOT/manifest.webmanifest" >/dev/null
echo "FKBC v4 update applied. Backup: $ROOT/.fkbc-backup-$STAMP"
echo "Next: git add -A && git commit -m 'Upgrade FKBC arcade presentation, facing, scale and SFX' && git push"
