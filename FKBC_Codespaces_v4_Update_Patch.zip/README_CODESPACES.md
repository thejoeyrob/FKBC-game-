# FKBC Fight Arcade — Codespaces v4 Update

This patch targets the existing flat `FKBC_Fight_Arcade_Complete_PWA` build.

## Changes
- Joe facing-direction mapping corrected so both fighters face each other.
- Fight sprites enlarged from roughly 190–230px visible body height to roughly 285–310px.
- Hurtboxes, attack ranges and push-apart distance rescaled to match the larger artwork.
- Controller reduced in size and restyled as a dark SNES/Mega Drive six-button controller.
- Main menu, character select, VS screen, options and results changed from modern rounded panels to 16-bit console presentation.
- Fight viewport remains locked to the 16:9 stage and page scrolling/overscroll is disabled.
- All ten SFX replaced with layered 44.1kHz PCM sounds: glove hits, kicks, heavy impacts, blocks, floor knockdown, projectile/tornado whooshes, round bell, menu select and victory sting.
- Service worker cache bumped to `fkbc-fight-complete-v4` so old cached CSS/JS/audio is discarded.

## Apply in GitHub Codespaces
Upload `FKBC_Codespaces_v4_Update_Patch.zip` into the repository root, then run:

```bash
unzip -o FKBC_Codespaces_v4_Update_Patch.zip -d /tmp/fkbc-v4
chmod +x /tmp/fkbc-v4/apply_update.sh
/tmp/fkbc-v4/apply_update.sh "$PWD"
git status
git add -A
git commit -m "Upgrade FKBC arcade presentation, facing, scale and SFX"
git push
```

If the repo is not your current directory, replace `$PWD` with its Codespaces path, e.g. `/workspaces/fkbc-fight-arcade`.

## Test before committing
From the repo root:

```bash
python3 -m http.server 8080
```

Open port 8080 from the **Ports** tab. Test in landscape. Stop the server with Ctrl+C.

## PWA cache after deploy
The service worker version is bumped. On an already-installed iPhone PWA, close it fully and reopen after deployment. If iOS still shows the prior build, remove the Home Screen app once and add it again; this is only for stale installations, not every update.
